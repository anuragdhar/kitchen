# Kitchen BOM - Galley 2324x3962 Current Configuration

* Countertop length: 7314 mm (7.31 m) x 600D/600D, thickness 38mm
* Backsplash area: 4.39 m2 (height 600mm)
* Base cabinets: 11 (East 6 + West 5)
* Wall lower (320D): 9
* Wall top (550D/450D): 9
* Shutters: 29
* Drawers: 23
* Handles: 0 (handleless fronts)

## Cabinet Modules East (600D run 3962mm)
| # | Width mm | Type |
|---|---|---|
| 1 | 900 | base |
| 2 | 900 | base |
| 3 | 900 | base |
| 4 | 900 | base |
| 5 | 300 | base |
| 6 | 62 | filler |

## Cabinet Modules West (600D run 3352mm)
| # | Width mm | Type |
|---|---|---|
| 1 | 900 | base |
| 2 | 900 | base |
| 3 | 900 | base |
| 4 | 600 | base |
| 5 | 52 | filler |

## Appliances
| Wall | ID | Y mm | Size |
|---|---|---|---|
| east | microwave | 0 | 600x400 |
| east | applianceGarage | 0 | 850x600 |
| east | eastBacksplashSlider | 0 | 3962x102 |
| east | gas | 1200 | 700x600 |
| west | shaft | 3124 | 609x838 |
| west | washing | 610 | 600x600 |
| west | sink | 1210 | 762x457 |
| west | sinkUpperDishRack | 1210 | 762x320 |
| west | dishwasher | 1972 | 600x600 |
| west | westSixInchSlider | 2572 | 552x152 |

## Notes
- Door clear zone y0-y610
- Window-only 300 mm below-sill reference
- Shaft y3124 NW
- East 4in backsplash slider storage
- West 6in slider storage between dishwasher and shaft
- Window north 1100W

## Materials
- Cabinet body #efe9df
- Shutters #b99673
- Counter #e7ded2
- Backsplash #faf6f1
- Floor #ded6cc
- Wall #f6efe6
- Handle style: handleless
